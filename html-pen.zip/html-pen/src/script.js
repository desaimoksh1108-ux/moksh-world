
/* =====================================================
   MOKSH WORLD 6.0
   ONLINE MULTIPLAYER TYPING BATTLE
   Supabase + Shared Timer + Player Progress
   ===================================================== */

// 1. SUPABASE CONNECTION
const SUPABASE_URL = "https://mcaumjrluxsytlelsemi.supabase.co/rest/v1/ ";
const SUPABASE_KEY = "sb_publishable_uptBgJJSaOsjtlVuqPf8jA_MMRCC5PM ";

const $ = (id) => document.getElementById(id);

if (!window.supabase || !window.supabase.createClient) {
  alert("Supabase library missing! Check HTML CDN script.");
  throw new Error("Supabase library not loaded.");
}

const db = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_KEY.trim()
);

// 2. GAME VARIABLES
let currentRoom = null;
let currentPlayerId = null;
let currentPlayerName = "";
let currentRoomData = null;
let currentPlayers = [];

let score = 0;
let currentWord = "";
let promptIndex = 0;

let adminRunning = false;
let adminPaused = false;
let adminMatchStatus = "WAITING";

let matchTimeLeft = 300;
let timerInterval = null;

let totalTyped = 0;
let correctTyped = 0;
let lastInputValue = "";

let teamABonus = 0;
let teamBBonus = 0;

let roomChannel = null;
let scoreSaving = false;
let lastMatchSeed = null;

// 3. PROMPT GENERATOR
const prefixes = [
  "Aarav","Vivaan","Aditya","Arjun","Sai","Reyansh",
  "Ayaan","Krishna","Ishaan","Shaurya","Advait","Atharv",
  "Kabir","Rudra","Dhruv","Vihaan","Rohan","Rahul",
  "Kunal","Sagar","Moksh","Dhaval","Purav","Harshil",
  "Yash","Dev","Jay","Veer","Neel","Om",
  "Fire","Dark","Super","Mega","Ultra","Shadow",
  "Royal","Rapid","Crazy","Smart","Power","Golden",
  "Fast","Flash","Cyber","Alpha","Elite","Mystic",
  "Cosmic","Storm"
];

const suffixes = [
  "Shah","Desai","Patel","Mehta","Joshi","Trivedi",
  "Pandya","Dave","Rao","Iyer","Sharma","Verma",
  "Gupta","Singh","Kumar","Malhotra","Kapoor","Chopra",
  "Reddy","Nair","Brown","Smith","Wilson","Taylor",
  "Johnson","Miller","Davis","Clark","Lewis","Walker",
  "Tiger","Dragon","Wolf","Eagle","Ninja","Warrior",
  "Knight","Ranger","Wizard","Hero","Champion","Pilot",
  "Racer","Hunter","Guardian","Legend","Gamer","Galaxy",
  "Rocket","Pixel"
];

const allTypingPrompts = [];

for (const prefix of prefixes) {
  for (const suffix of suffixes) {
    for (let n = 1; n <= 40; n++) {
      allTypingPrompts.push(prefix + suffix + n);
    }
  }
}

// Same seed + same index = same word on every device.
function getSharedPrompt(seed, index) {
  const source = String(seed) + ":" + String(index);
  let hash = 2166136261;

  for (let i = 0; i < source.length; i++) {
    hash ^= source.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }

  const position = (hash >>> 0) % allTypingPrompts.length;
  return allTypingPrompts[position];
}

// 4. MESSAGES
function showMessage(message) {
  if ($("result")) $("result").textContent = message;
}

function ownerMessage(message) {
  if ($("ownerMessage")) {
    $("ownerMessage").textContent = message;
  }
}

function settingsMessage(message) {
  if ($("settingsMessage")) {
    $("settingsMessage").textContent = message;
  }
}

function getPlayerName() {
  return $("playerName")?.value.trim() || "Player";
}

// 5. PLAYER HELPERS
function getCurrentPlayer() {
  return currentPlayers.find(p => p.id === currentPlayerId) || null;
}

function getTeamPlayers(team) {
  return currentPlayers.filter(p => p.team === team);
}

function getTeamScore(team) {
  return getTeamPlayers(team).reduce(
    (total, player) => total + Number(player.score || 0),
    0
  ) + (team === "A" ? teamABonus : teamBBonus);
}

// 6. ROOM DISPLAY
function showRoom() {
  if (!currentRoomData) return;

  if ($("roomId")) {
    $("roomId").textContent = currentRoom || "";
  }

  if ($("roomStatus")) {
    $("roomStatus").textContent =
      currentPlayers.length + "/" +
      currentRoomData.max_players + " Players Joined";
  }

  const playerBox = $("players");

  if (playerBox) {
    playerBox.innerHTML = "";

    for (let i = 0; i < currentRoomData.max_players; i++) {
      const div = document.createElement("div");
      div.className = "player";

      div.textContent = currentPlayers[i]
        ? "👤 " + currentPlayers[i].player_name
        : "👤 Empty";

      playerBox.appendChild(div);
    }
  }

  updateTeams();
  updateLeaderboard();
  updateAdminPanel();
}

// 7. TEAM DISPLAY
function updateTeams() {
  const teamA = getTeamPlayers("A");
  const teamB = getTeamPlayers("B");

  if ($("teamAPlayers")) {
    $("teamAPlayers").textContent = teamA.length
      ? teamA.map(p => p.player_name).join(" | ")
      : "No players";
  }

  if ($("teamBPlayers")) {
    $("teamBPlayers").textContent = teamB.length
      ? teamB.map(p => p.player_name).join(" | ")
      : "No players";
  }

  if ($("teamAScore")) {
    $("teamAScore").textContent = getTeamScore("A");
  }

  if ($("teamBScore")) {
    $("teamBScore").textContent = getTeamScore("B");
  }
}

// 8. LIVE LEADERBOARD
function updateLeaderboard() {
  const list = $("leaderboardList");
  if (!list) return;

  list.innerHTML = "";

  const sorted = [...currentPlayers].sort(
    (a, b) => Number(b.score || 0) - Number(a.score || 0)
  );

  if (!sorted.length) {
    list.textContent = "No players yet";
    return;
  }

  sorted.forEach((player, index) => {
    const row = document.createElement("div");
    row.className = "leader-row";

    const rank = document.createElement("span");
    rank.className = "leader-rank";
    rank.textContent = "#" + (index + 1);

    const name = document.createElement("span");
    name.textContent = player.player_name;

    const points = document.createElement("span");
    points.textContent = player.score || 0;

    row.append(rank, name, points);
    list.appendChild(row);
  });
}

// 9. ADMIN PANEL
function updateAdminPanel() {
  if ($("adminPlayers")) {
    $("adminPlayers").textContent =
      currentPlayers.length + " / " +
      (currentRoomData?.max_players || 0);
  }

  const startTime = currentRoomData?.match_started_at
    ? new Date(currentRoomData.match_started_at).getTime()
    : 0;

  const elapsed = startTime
    ? Math.max(0, (Date.now() - startTime) / 1000)
    : 0;

  const wpm = elapsed > 0
    ? Math.round((correctTyped / 5) / (elapsed / 60))
    : 0;

  const accuracy = totalTyped > 0
    ? Math.round(correctTyped / totalTyped * 100)
    : 100;

  if ($("adminStatus")) {
    $("adminStatus").textContent = adminMatchStatus;
  }

  if ($("adminReport")) {
    $("adminReport").textContent =
      "Player: " + (currentPlayerName || "No player") +
      " | Score: " + score +
      " | Speed: " + wpm + " WPM" +
      " | Accuracy: " + accuracy + "%";
  }
}

// 10. REFRESH PLAYERS
async function refreshRoomPlayers() {
  if (!currentRoom) return;

  const { data, error } = await db
    .from("game_players")
    .select("*")
    .eq("room_code", currentRoom)
    .order("joined_at", { ascending: true });

  if (error) {
    console.error("Player refresh:", error.message);
    return;
  }

  currentPlayers = data || [];

  const me = getCurrentPlayer();

  if (me) {
    score = Number(me.score || 0);
    promptIndex = Number(me.prompt_index || 0);

    if ($("score")) {
      $("score").textContent = score;
    }

    if (adminRunning && !scoreSaving) {
      displayCurrentPrompt();
    }
  }

  showRoom();
}

// 11. SHARED PROMPT
function displayCurrentPrompt() {
  if (!currentRoomData || !currentPlayerId) return;

  const me = getCurrentPlayer();
  if (!me) return;

  promptIndex = Number(me.prompt_index || 0);

  currentWord = getSharedPrompt(
    currentRoomData.match_seed,
    promptIndex
  );

  if ($("word")) {
    $("word").textContent = currentWord;
  }

  if ($("typing")) {
    $("typing").value = "";
    $("typing").disabled = !adminRunning || adminPaused;
  }

  lastInputValue = "";
}

// 12. TIMER DISPLAY
function calculateRemainingTime() {
  if (!currentRoomData) return matchTimeLeft;

  if (currentRoomData.status === "paused") {
    return Number(
      currentRoomData.match_remaining_seconds ?? matchTimeLeft
    );
  }

  if (currentRoomData.status !== "playing") {
    return matchTimeLeft;
  }

  const start = new Date(
    currentRoomData.match_started_at
  ).getTime();

  if (!start || Number.isNaN(start)) return matchTimeLeft;

  const duration = Number(
    currentRoomData.match_duration_seconds || 300
  );

  const elapsed = (Date.now() - start) / 1000;

  return Math.max(0, Math.ceil(duration - elapsed));
}

function showTimer() {
  const minutes = Math.floor(matchTimeLeft / 60);
  const seconds = matchTimeLeft % 60;

  if ($("matchTimer")) {
    $("matchTimer").textContent =
      "TIME: " +
      String(minutes).padStart(2, "0") +
      ":" +
      String(seconds).padStart(2, "0");
  }
}

function startTimer() {
  clearInterval(timerInterval);

  timerInterval = setInterval(async () => {
    if (!adminRunning || adminPaused) return;

    matchTimeLeft = calculateRemainingTime();
    showTimer();

    if (matchTimeLeft <= 0) {
      clearInterval(timerInterval);
      await finishOnlineMatch("TIME UP! MATCH FINISHED");
    }
  }, 500);
}

// 13. START LOCAL MATCH
function startLocalMatch() {
  if (!currentRoomData) return;

  const newSeed = currentRoomData.match_seed;

  if (lastMatchSeed !== newSeed) {
    score = 0;
    totalTyped = 0;
    correctTyped = 0;
    teamABonus = 0;
    teamBBonus = 0;
    lastMatchSeed = newSeed;
  }

  adminRunning = true;
  adminPaused = false;
  adminMatchStatus = "PLAYING";

  matchTimeLeft = calculateRemainingTime();

  if ($("score")) $("score").textContent = score;

  if ($("teamWinner")) {
    $("teamWinner").textContent = "MATCH IN PROGRESS";
  }

  showMessage("Typing Battle Started!");

  displayCurrentPrompt();
  showTimer();
  startTimer();
  updateTeams();
  updateAdminPanel();
}

// 14. PAUSE LOCAL MATCH
function pauseLocalMatch() {
  if (!adminRunning) return;

  adminPaused = true;
  adminMatchStatus = "PAUSED";

  clearInterval(timerInterval);

  matchTimeLeft = calculateRemainingTime();
  showTimer();

  if ($("typing")) $("typing").disabled = true;

  showMessage("MATCH PAUSED");
  updateAdminPanel();
}

// 15. FINISH LOCAL MATCH
function announceWinner() {
  const a = getTeamScore("A");
  const b = getTeamScore("B");

  if (!$("teamWinner")) return;

  if (a > b) {
    $("teamWinner").textContent = "🏆 TEAM A WINS!";
  } else if (b > a) {
    $("teamWinner").textContent = "🏆 TEAM B WINS!";
  } else {
    $("teamWinner").textContent = "🤝 MATCH DRAW!";
  }
}

function finishLocalMatch(message) {
  clearInterval(timerInterval);

  adminRunning = false;
  adminPaused = false;
  adminMatchStatus = "FINISHED";

  if ($("typing")) $("typing").disabled = true;

  showMessage(message);
  updateTeams();
  announceWinner();
  updateLeaderboard();
  updateAdminPanel();
}

// 16. SYNC ROOM STATE
function applyRoomState(room) {
  if (!room) return;

  currentRoomData = room;

  if (room.status === "playing") {
    if (!adminRunning || adminPaused) {
      startLocalMatch();
    } else {
      matchTimeLeft = calculateRemainingTime();
      showTimer();
    }
  }

  if (room.status === "paused") {
    if (adminRunning && !adminPaused) {
      pauseLocalMatch();
    } else {
      adminPaused = true;
      adminMatchStatus = "PAUSED";
      matchTimeLeft = calculateRemainingTime();
      showTimer();
    }
  }

  if (room.status === "finished") {
    if (adminRunning) {
      finishLocalMatch("MATCH FINISHED");
    }
  }

  if (room.status === "waiting") {
    if (adminRunning) {
      finishLocalMatch("MATCH STOPPED");
    }

    adminMatchStatus = "WAITING";
  }

  showRoom();
}

// 17. REALTIME CONNECTION
function disconnectRoomChannel() {
  if (roomChannel) {
    db.removeChannel(roomChannel);
    roomChannel = null;
  }
}

function connectRoomChannel() {
  disconnectRoomChannel();

  if (!currentRoom) return;

  roomChannel = db
    .channel("moksh-world-6-" + currentRoom)

    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "game_players",
        filter: "room_code=eq." + currentRoom
      },
      async () => {
        await refreshRoomPlayers();
      }
    )

    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "game_rooms",
        filter: "room_code=eq." + currentRoom
      },
      async (payload) => {
        applyRoomState(payload.new);
      }
    )

    .subscribe((status) => {
      console.log("MOKSH WORLD 6 realtime:", status);
    });
}

// 18. CREATE ROOM
async function createRoom() {
  if (adminRunning) {
    showMessage("Stop the current match first!");
    return;
  }

  const name = getPlayerName();
  const maxPlayers = Number($("maxPlayers")?.value || 6);

  if (maxPlayers < 2 || maxPlayers > 9) {
    showMessage("Maximum players must be between 2 and 9.");
    return;
  }

  showMessage("Creating online room...");

  const roomCode =
    "MW" + Math.floor(1000 + Math.random() * 9000);

  const { data: room, error: roomError } = await db
    .from("game_rooms")
    .insert({
      room_code: roomCode,
      room_name: "MOKSH WORLD ROOM " + roomCode,
      status: "waiting",
      max_players: maxPlayers,
      match_duration_seconds: 300,
      match_remaining_seconds: 300,
      match_round: 0
    })
    .select()
    .single();

  if (roomError) {
    showMessage("Room creation failed: " + roomError.message);
    return;
  }

  const { data: player, error: playerError } = await db
    .from("game_players")
    .insert({
      room_code: roomCode,
      player_name: name,
      team: "A",
      score: 0,
      wpm: 0,
      accuracy: 100,
      prompt_index: 0
    })
    .select()
    .single();

  if (playerError) {
    showMessage("Player join failed: " + playerError.message);
    return;
  }

  currentRoom = roomCode;
  currentRoomData = room;
  currentPlayerId = player.id;
  currentPlayerName = name;

  score = 0;
  promptIndex = 0;

  if ($("roomCode")) $("roomCode").value = roomCode;
  if ($("score")) $("score").textContent = "0";

  await refreshRoomPlayers();
  connectRoomChannel();

  showMessage("Online room created! ID: " + roomCode);
}

// 19. JOIN ROOM
async function joinRoom() {
  if (adminRunning) {
    showMessage("Stop the current match first!");
    return;
  }

  const roomCode = $("roomCode")?.value.trim().toUpperCase();
  const name = getPlayerName();

  if (!roomCode) {
    showMessage("Enter Room ID first!");
    return;
  }

  showMessage("Searching online room...");

  const { data: room, error: roomError } = await db
    .from("game_rooms")
    .select("*")
    .eq("room_code", roomCode)
    .maybeSingle();

  if (roomError || !room) {
    showMessage("Room not found!");
    return;
  }

  if (room.status !== "waiting") {
    showMessage("This room is not accepting new players.");
    return;
  }

  const { data: existing, error: listError } = await db
    .from("game_players")
    .select("*")
    .eq("room_code", roomCode);

  if (listError) {
    showMessage("Could not load players: " + listError.message);
    return;
  }

  if (existing.length >= room.max_players) {
    showMessage("Room is full!");
    return;
  }

  if (existing.some(p =>
    p.player_name.toLowerCase() === name.toLowerCase()
  )) {
    showMessage("Name already exists in this room!");
    return;
  }

  const team = existing.length % 2 === 0 ? "A" : "B";

  const { data: player, error: joinError } = await db
    .from("game_players")
    .insert({
      room_code: roomCode,
      player_name: name,
      team,
      score: 0,
      wpm: 0,
      accuracy: 100,
      prompt_index: 0
    })
    .select()
    .single();

  if (joinError) {
    showMessage("Join failed: " + joinError.message);
    return;
  }

  currentRoom = roomCode;
  currentRoomData = room;
  currentPlayerId = player.id;
  currentPlayerName = name;

  score = 0;
  promptIndex = 0;

  await refreshRoomPlayers();
  connectRoomChannel();

  showMessage("Successfully joined online room!");
}

// 20. BUTTON CONNECTIONS
$("createRoom")?.addEventListener("click", createRoom);
$("joinRoom")?.addEventListener("click", joinRoom);

// 21. SAVE PLAYER SCORE AND PROGRESS
async function saveMyScore() {
  if (!currentPlayerId) return;

  const startTime = currentRoomData?.match_started_at
    ? new Date(currentRoomData.match_started_at).getTime()
    : Date.now();

  const elapsed = Math.max(1, (Date.now() - startTime) / 1000);

  const wpm = Math.round((correctTyped / 5) / (elapsed / 60));

  const accuracy = totalTyped > 0
    ? Math.round(correctTyped / totalTyped * 100)
    : 100;

  const { error } = await db
    .from("game_players")
    .update({
      score,
      wpm,
      accuracy,
      prompt_index: promptIndex
    })
    .eq("id", currentPlayerId);

  if (error) {
    console.error("Score sync error:", error.message);
    showMessage("Score sync error: " + error.message);
  }
}

// 22. TYPING SYSTEM
$("typing")?.addEventListener("input", async function() {
  if (
    !adminRunning ||
    adminPaused ||
    !currentPlayerId ||
    scoreSaving
  ) return;

  const value = this.value;

  if (value.length > lastInputValue.length) {
    const added = value.slice(lastInputValue.length);

    for (let i = 0; i < added.length; i++) {
      const position = lastInputValue.length + i;

      totalTyped++;

      if (
        currentWord[position] &&
        added[i].toLowerCase() ===
        currentWord[position].toLowerCase()
      ) {
        correctTyped++;
      }
    }
  }

  lastInputValue = value;
  updateAdminPanel();

  if (value.toLowerCase() === currentWord.toLowerCase()) {
    scoreSaving = true;

    score += 10;
    promptIndex++;

    if ($("score")) $("score").textContent = score;

    showMessage("Correct! +10 Points!");

    const me = getCurrentPlayer();

    if (me) {
      me.score = score;
      me.prompt_index = promptIndex;
    }

    updateTeams();
    updateLeaderboard();
    updateAdminPanel();

    if ($("typing")) $("typing").disabled = true;

    await saveMyScore();

    displayCurrentPrompt();

    scoreSaving = false;
  }
});

// 23. START ONLINE MATCH
async function startOnlineMatch() {
  if (!currentRoom) {
    showMessage("Create or join a room first!");
    return;
  }

  if (adminRunning) {
    showMessage("Match is already running!");
    return;
  }

  showMessage("Starting online match...");

  const durationMinutes = Number(
    $("matchDuration")?.value || 5
  );

  const durationSeconds = durationMinutes * 60;
  const seed = Math.floor(Math.random() * 2000000000) + 1;

  // Reset every player's score and prompt progress.
  const { error: resetError } = await db
    .from("game_players")
    .update({
      score: 0,
      wpm: 0,
      accuracy: 100,
      prompt_index: 0
    })
    .eq("room_code", currentRoom);

  if (resetError) {
    showMessage("Player reset failed: " + resetError.message);
    return;
  }

  const startTime = new Date().toISOString();

  const { data: room, error } = await db
    .from("game_rooms")
    .update({
      status: "playing",
      match_started_at: startTime,
      match_duration_seconds: durationSeconds,
      match_remaining_seconds: durationSeconds,
      match_paused_at: null,
      match_seed: seed,
      match_round: 0
    })
    .eq("room_code", currentRoom)
    .select()
    .single();

  if (error) {
    showMessage("Could not start match: " + error.message);
    return;
  }

  currentRoomData = room;
  await refreshRoomPlayers();
  applyRoomState(room);
}

$("startBtn")?.addEventListener("click", startOnlineMatch);

// 24. PAUSE ONLINE MATCH
async function pauseOnlineMatch() {
  if (!currentRoom || !adminRunning || adminPaused) {
    showMessage("Match is not running!");
    return;
  }

  const remaining = calculateRemainingTime();

  const { data: room, error } = await db
    .from("game_rooms")
    .update({
      status: "paused",
      match_remaining_seconds: remaining,
      match_paused_at: new Date().toISOString()
    })
    .eq("room_code", currentRoom)
    .select()
    .single();

  if (error) {
    showMessage("Pause failed: " + error.message);
    return;
  }

  applyRoomState(room);
}

$("pauseMatch")?.addEventListener("click", pauseOnlineMatch);

// 25. RESUME ONLINE MATCH
async function resumeOnlineMatch() {
  if (!currentRoom || !adminRunning || !adminPaused) {
    showMessage("Match is not paused!");
    return;
  }

  const remaining = Number(
    currentRoomData?.match_remaining_seconds ?? matchTimeLeft
  );

  const duration = Number(
    currentRoomData?.match_duration_seconds || 300
  );

  const elapsed = duration - remaining;

  const newStartTime = new Date(
    Date.now() - elapsed * 1000
  ).toISOString();

  const { data: room, error } = await db
    .from("game_rooms")
    .update({
      status: "playing",
      match_started_at: newStartTime,
      match_paused_at: null
    })
    .eq("room_code", currentRoom)
    .select()
    .single();

  if (error) {
    showMessage("Resume failed: " + error.message);
    return;
  }

  applyRoomState(room);
}

$("resumeMatch")?.addEventListener("click", resumeOnlineMatch);

// 26. FINISH ONLINE MATCH
async function finishOnlineMatch(message) {
  if (!currentRoom) {
    finishLocalMatch(message);
    return;
  }

  const { data: room, error } = await db
    .from("game_rooms")
    .update({
      status: "finished",
      match_remaining_seconds: 0
    })
    .eq("room_code", currentRoom)
    .select()
    .single();

  if (error) {
    showMessage("Finish update failed: " + error.message);
    return;
  }

  currentRoomData = room;
  finishLocalMatch(message);
}

$("stopMatch")?.addEventListener("click", async () => {
  if (!adminRunning) {
    showMessage("No active match!");
    return;
  }

  await finishOnlineMatch("MATCH STOPPED");
});

// 27. OWNER WINNER BUTTON
$("announceWinner")?.addEventListener("click", () => {
  updateTeams();
  announceWinner();
  ownerMessage("Winner announced!");
});

// 28. MOVE PLAYER TO TEAM
async function movePlayerToTeam(name, team) {
  if (!currentRoom) {
    ownerMessage("Create or join a room first!");
    return;
  }

  const player = currentPlayers.find(
    p => p.player_name.toLowerCase() === name.toLowerCase()
  );

  if (!player) {
    ownerMessage("Player not found!");
    return;
  }

  const { error } = await db
    .from("game_players")
    .update({ team })
    .eq("id", player.id);

  if (error) {
    ownerMessage("Team update failed: " + error.message);
    return;
  }

  ownerMessage(name + " moved to Team " + team + "!");
  await refreshRoomPlayers();
}

$("sendTeamA")?.addEventListener("click", () => {
  movePlayerToTeam($("ownerPlayerName")?.value.trim(), "A");
});

$("sendTeamB")?.addEventListener("click", () => {
  movePlayerToTeam($("ownerPlayerName")?.value.trim(), "B");
});

// 29. TEAM BONUS
$("addTeamA")?.addEventListener("click", () => {
  teamABonus += 10;
  updateTeams();
  ownerMessage("Team A received 10 points!");
});

$("addTeamB")?.addEventListener("click", () => {
  teamBBonus += 10;
  updateTeams();
  ownerMessage("Team B received 10 points!");
});

// 30. RESET TEAMS
$("resetTeams")?.addEventListener("click", async () => {
  if (!currentRoom) {
    ownerMessage("Join a room first!");
    return;
  }

  teamABonus = 0;
  teamBBonus = 0;

  for (let i = 0; i < currentPlayers.length; i++) {
    const team = i % 2 === 0 ? "A" : "B";

    const { error } = await db
      .from("game_players")
      .update({ team })
      .eq("id", currentPlayers[i].id);

    if (error) {
      ownerMessage("Team reset error: " + error.message);
      return;
    }
  }

  if ($("teamWinner")) {
    $("teamWinner").textContent = "WAITING FOR MATCH";
  }

  ownerMessage("Teams reset!");
  await refreshRoomPlayers();
});

// 31. MAX PLAYERS SETTINGS
$("maxPlayers")?.addEventListener("change", async function() {
  const max = Number(this.value);

  if (max < 2 || max > 9) {
    settingsMessage("Maximum players must be 2 to 9.");
    return;
  }

  if (!currentRoom) {
    settingsMessage("Maximum players: " + max);
    return;
  }

  if (currentPlayers.length > max) {
    settingsMessage("Current room has more players than this limit!");
    return;
  }

  const { data, error } = await db
    .from("game_rooms")
    .update({ max_players: max })
    .eq("room_code", currentRoom)
    .select()
    .single();

  if (error) {
    settingsMessage("Settings update failed: " + error.message);
    return;
  }

  currentRoomData = data;
  showRoom();
  settingsMessage("Maximum players updated: " + max);
});

// 32. DIFFICULTY SETTINGS
$("wordDifficulty")?.addEventListener("change", function() {
  settingsMessage(
    "Difficulty selected: " + this.value.toUpperCase() +
    ". New shared prompt sequence uses the common word list."
  );
});

// 33. MATCH DURATION SETTINGS
$("matchDuration")?.addEventListener("change", function() {
  settingsMessage("Duration selected: " + this.value + " minute(s)");
});

// 34. INITIAL DISPLAY
if ($("typing")) {
  $("typing").disabled = true;
}

showTimer();
updateTeams();
updateLeaderboard();
updateAdminPanel();

console.log("MOKSH WORLD 6.0 LOADED");
console.log("Typing prompts:", allTypingPrompts.length);
console.log("Supabase:", !!window.supabase);
console.log("Shared prompt system: READY");
console.log("Shared timer system: READY");
